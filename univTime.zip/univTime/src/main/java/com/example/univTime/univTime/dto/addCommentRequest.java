package com.example.univTime.univTime.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class addCommentRequest {
    private String nickname;
    private String body;
}

