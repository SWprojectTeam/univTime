package com.example.univTime.univTime.service;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AuthService {
    private final List<User> users = new ArrayList<>(); // 사용자 목록

    public String register(String id, String password) {
        for (User user : users) {
            if (user.getId().equals(id)) {
                return "이미 존재하는 아이디입니다.";
            }
        }
        users.add(new User(id, password));
        return "회원가입 성공!";
    }

    public String login(String id, String password) {
        for (User user : users) {
            if (user.getId().equals(id) && user.getPassword().equals(password)) {
                return "로그인 성공!";
            }
        }
        return "아이디 또는 비밀번호가 잘못되었습니다.";
    }

    // 내부 사용자 클래스
    private class User {
        private final String id;
        private final String password;

        public User(String id, String password) {
            this.id = id;
            this.password = password;
        }

        public String getId() {
            return id;
        }

        public String getPassword() {
            return password;
        }
    }
}
