package com.example.univTime.univTime.controller;

import com.example.univTime.univTime.dto.RegisterRequest;
import com.example.univTime.univTime.dto.LoginRequest;
import com.example.univTime.univTime.dto.ResponseMessage;
import com.example.univTime.univTime.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class AuthApiController {
    @Autowired
    private AuthService authService;

    // 회원가입 API
    @PostMapping("/api/auth/register")
    public ResponseEntity<ResponseMessage> register(@RequestBody RegisterRequest request) {
        String result = String.valueOf(authService.register(request.getId(), request.getPassword()));
        HttpStatus status = result.equals("회원가입 성공!") ? HttpStatus.CREATED : HttpStatus.BAD_REQUEST;
        return ResponseEntity.status(status).body(new ResponseMessage(result));
    }

    // 로그인 API
    @PostMapping("/api/auth/login")
    public ResponseEntity<ResponseMessage> login(@RequestBody LoginRequest request) {
        String result = String.valueOf(authService.login(request.getId(), request.getPassword()));
        HttpStatus status = result.equals("로그인 성공!") ? HttpStatus.OK : HttpStatus.UNAUTHORIZED;
        return ResponseEntity.status(status).body(new ResponseMessage(result));
    }
}
