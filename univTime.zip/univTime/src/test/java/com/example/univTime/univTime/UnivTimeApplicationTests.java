package com.example.univTime.univTime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnivTimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
